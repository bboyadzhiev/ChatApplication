/**
 * Application Settings
 */

var appSettings = {

    everlive: {
        apiKey: '3Xg5eRJIktn0MNkV', // Backend Services API key 
        scheme: 'http'
    }
}