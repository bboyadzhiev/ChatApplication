/**
 * User profile view model
 */
var app = app || {};

app.UserProfile = (function () {
    'use strict';

    var userProfileViewModel = (function () {



        return {
            title: "User Profile"
        }

    }());

    return userProfileViewModel;

}());